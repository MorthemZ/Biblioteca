package com.clase;

import java.util.ArrayList;

public class Usuario {
    private String nombre;
    private int numeroIdentificacion;
    private ArrayList<Libro> librosPrestados;

    public Usuario(String nombre, int numeroIdentificacion) {
        this.nombre = nombre;
        this.numeroIdentificacion = numeroIdentificacion;
        this.librosPrestados = new ArrayList<>();
    }

    // Getters y setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getNumeroIdentificacion() {
        return numeroIdentificacion;
    }

    public void setNumeroIdentificacion(int numeroIdentificacion) {
        this.numeroIdentificacion = numeroIdentificacion;
    }

    public ArrayList<Libro> getLibrosPrestados() {
        return librosPrestados;
    }

    public void setLibrosPrestados(ArrayList<Libro> librosPrestados) {
        this.librosPrestados = librosPrestados;
    }

    @Override
    public String toString() {
        return "Usuario {" +
                "\n\tNombre: " + nombre +
                "\n\tNumero de Identificacion: " + numeroIdentificacion +
                "\n\tLibros Prestados: " + librosPrestados +
                "\n}";
    }
}