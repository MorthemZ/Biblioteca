package ui;

import java.util.ArrayList;
import java.util.Scanner;
import com.clase.Libro;
import com.clase.Usuario;
import service.LibroServicio;
import service.UsuarioServicio;

public class Main {
    public static void main(String[] args) {

        ArrayList<Usuario> usuariosRegistrados = new ArrayList<>();
        ArrayList<Libro> inventarioLibros = new ArrayList<>();


        UsuarioServicio usuarioServicio = new UsuarioServicio(usuariosRegistrados, inventarioLibros);
        LibroServicio libroServicio = new LibroServicio(inventarioLibros);

        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {

            System.out.println(" ---------- Menú Principal ---------- ");
            System.out.println("1. Crear Usuario");
            System.out.println("2. Actualizar Usuario");
            System.out.println("3. Buscar Usuario por Numero de Identificacion");
            System.out.println("4. Listar Libros Prestados de un Usuario");
            System.out.println("5. Eliminar Usuario");
            System.out.println("6. Reservar Libro");
            System.out.println("7. Devolver Libro");
            System.out.println("8. Crear Libro");
            System.out.println("9. Actualizar Libro");
            System.out.println("10. Buscar Libro por ISBN");
            System.out.println("11. Buscar Libro por Título");
            System.out.println("12. Listar Libros");
            System.out.println("13. Eliminar Libro");
            System.out.println("14. Verificar Disponibilidad de Libro");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opcion: ");
            opcion = scanner.nextInt();
            scanner.nextLine();


            switch (opcion) {
                case 1:
                    usuarioServicio.crearUsuario();
                    break;
                case 2:
                    usuarioServicio.actualizarUsuario();
                    break;
                case 3:
                    usuarioServicio.buscarUsuarioPorNumeroDeIdentificacion();
                    break;
                case 4:
                    usuarioServicio.listarLibrosPrestados();
                    break;
                case 5:
                    usuarioServicio.eliminarUsuario();
                    break;
                case 6:
                    usuarioServicio.prestarLibro();
                    break;
                case 7:
                    usuarioServicio.devolverLibro();
                    break;
                case 8:
                    libroServicio.crearLibro();
                    break;
                case 9:
                    libroServicio.actualizarLibro();
                    break;
                case 10:
                    libroServicio.buscarLibroPorISBN();
                    break;
                case 11:
                    libroServicio.buscarLibroPorTitulo();
                    break;
                case 12:
                    libroServicio.listarLibros();
                    break;
                case 13:
                    libroServicio.eliminarLibro();
                    break;
                case 14:
                    libroServicio.verificarDisponibilidad();
                    break;
                case 0:
                    System.out.println("Saliendo del programa.....");
                    break;
                default:
                    System.out.println("Opcion no valida. Por favor, seleccione una opcion que si lo sea.");
                    break;
            }
        } while (opcion != 0);


        scanner.close();
    }
}
