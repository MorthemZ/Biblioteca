package service;

import java.util.ArrayList;
import java.util.Scanner;

import com.clase.Libro;

public class LibroServicio {

    private ArrayList<Libro> inventario;

    public LibroServicio(ArrayList<Libro> inventario) {
        this.inventario = inventario;
    }

    public void crearLibro() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese los datos del nuevo libro:");
        System.out.print("Titulo: ");
        String titulo = scanner.nextLine();

        System.out.print("Autor: ");
        String autor = scanner.nextLine();

        System.out.print("ISBN: ");
        String isbn = scanner.nextLine();

        System.out.print("Genero: ");
        String genero = scanner.nextLine();


        if (titulo.isEmpty() || autor.isEmpty() || isbn.isEmpty() || genero.isEmpty()) {
            System.out.println("Error: Todos los campos deben ser completados.");
            return;
        }


        Libro nuevoLibro = new Libro(titulo, autor, isbn, genero, true, null);


        inventario.add(nuevoLibro);

        System.out.println("Nuevo libro agregado al inventario correctamente.");
    }

    public void actualizarLibro() {
        Scanner scanner = new Scanner(System.in);


        System.out.println("Ingrese el ISBN del libro a editar:");
        String isbn = scanner.nextLine();


        if (isbn.isEmpty()) {
            System.out.println("Error: Debe ingresar el ISBN del libro.");
            return;
        }


        Libro libroEncontrado = null;
        for (Libro libro : inventario) {
            if (libro.getISBN().equalsIgnoreCase(isbn)) {
                libroEncontrado = libro;
                break;
            }
        }


        if (libroEncontrado != null) {

            System.out.println("Libro encontrado:");
            System.out.println(libroEncontrado);


            System.out.println("Ingrese los nuevos datos del libro:");

            System.out.print("Titulo: ");
            String titulo = scanner.nextLine();
            if (!titulo.isEmpty()) {
                libroEncontrado.setTitulo(titulo);
            }

            System.out.print("Autor: ");
            String autor = scanner.nextLine();
            if (!autor.isEmpty()) {
                libroEncontrado.setAutor(autor);
            }

            System.out.print("Genero: ");
            String genero = scanner.nextLine();
            if (!genero.isEmpty()) {
                libroEncontrado.setGenero(genero);
            }


            System.out.println("El libro ha sido actualizado correctamente.");
        } else {
            System.out.println("No se encontro ningún libro con ese ISBN");
        }
    }

    public void buscarLibroPorISBN() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese el ISBN del libro a buscar:");
        String isbn = scanner.nextLine();


        if (isbn.isEmpty()) {
            System.out.println("Error: Debe ingresar el ISBN del libro.");
            return;
        }


        boolean encontrado = false;
        for (Libro libro : inventario) {
            if (libro.getISBN().equals(isbn)) {
                System.out.println("Libro encontrado:");
                System.out.println(libro);
                encontrado = true;
                break;
            }
        }

        if (!encontrado) {
            System.out.println("No se encontro ningun libro con ese ISBN.");
        }
    }

    public void buscarLibroPorTitulo() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese el titulo del libro a buscar:");
        String titulo = scanner.nextLine();


        if (titulo.isEmpty()) {
            System.out.println("Error: Debe ingresar el titulo del libro.");
            return;
        }


        boolean encontrado = false;
        for (Libro libro : inventario) {
            if (libro.getTitulo().equalsIgnoreCase(titulo)) {
                System.out.println("Libro encontrado:");
                System.out.println(libro);
                encontrado = true;
                break;
            }
        }

        if (!encontrado) {
            System.out.println("No se encontro ningun libro con el título proporcionado.");
        }
    }

    public void listarLibros() {
        System.out.println("Listado de libros en el inventario:");
        if (inventario.isEmpty()) {
            System.out.println("El inventario esta vacío.");
        } else {
            for (Libro libro : inventario) {
                System.out.println(libro);
            }
        }
    }

    public void eliminarLibro() {
        Scanner scanner = new Scanner(System.in);


        System.out.println("Ingrese el ISBN del libro a eliminar:");
        String isbn = scanner.nextLine();


        if (isbn.isEmpty()) {
            System.out.println("Error: Debe ingresar el ISBN del libro.");
            return;
        }


        Libro libroEncontrado = null;
        for (Libro libro : inventario) {
            if (libro.getISBN().equalsIgnoreCase(isbn)) {
                libroEncontrado = libro;
                break;
            }
        }


        if (libroEncontrado != null) {

            System.out.println("Libro encontrado:");
            System.out.println(libroEncontrado);
            System.out.println("¿Estas seguro de que deseas eliminar este libro? (S/N)");
            String respuesta = scanner.nextLine().toUpperCase();
            if (respuesta.equals("S")) {

                inventario.remove(libroEncontrado);
                System.out.println("El libro ha sido eliminado del inventario.");
            } else {
                System.out.println("Eliminacion cancelada.");
            }
        } else {
            System.out.println("No se encontro ningun libro con ese ISBN.");
        }
    }

    public void verificarDisponibilidad() {
        Scanner scanner = new Scanner(System.in);


        System.out.println("Ingrese el titulo del libro a verificar:");
        String titulo = scanner.nextLine();


        if (titulo.isEmpty()) {
            System.out.println("Error: Debe ingresar el titulo del libro.");
            return;
        }


        Libro libroEncontrado = null;
        for (Libro libro : inventario) {
            if (libro.getTitulo().equalsIgnoreCase(titulo)) {
                libroEncontrado = libro;
                break;
            }
        }


        if (libroEncontrado != null) {

            if (libroEncontrado.isDisponible()) {
                System.out.println("El libro esta disponible.");
            } else {
                System.out.println("El libro no esta disponible.");
            }
        } else {
            System.out.println("No se encontro ningun libro con ese titulo");
        }
    }
}