package service;

import java.util.ArrayList;
import java.util.Scanner;

import com.clase.Libro;
import com.clase.Usuario;

public class UsuarioServicio {

    private ArrayList<Usuario> usuariosRegistrados;
    private ArrayList<Libro> inventarioLibros;

    public UsuarioServicio(ArrayList<Usuario> usuariosRegistrados, ArrayList<Libro> inventarioLibros) {
        this.usuariosRegistrados = usuariosRegistrados;
        this.inventarioLibros = inventarioLibros;
    }

    public void crearUsuario() {
        Scanner scanner = new Scanner(System.in);


        System.out.println("Ingrese datos del nuevo usuario:");
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();

        System.out.print("Numero de identificacion: ");
        int numeroIdentificacion = scanner.nextInt();
        scanner.nextLine();


        if (nombre.isEmpty()) {
            System.out.println("Error: El nombre del usuario tiene que contener algo.");
            return;
        }


        Usuario nuevoUsuario = new Usuario(nombre, numeroIdentificacion);


        usuariosRegistrados.add(nuevoUsuario);

        System.out.println("Nuevo usuario registrado correctamente.");
    }

    public void actualizarUsuario() {
        Scanner scanner = new Scanner(System.in);


        System.out.println("Ingrese el numero identificador del usuario a editar:");
        int numeroIdentificador = scanner.nextInt();
        scanner.nextLine();


        if (numeroIdentificador <= 0) {
            System.out.println("Debe ingresar un numero identificador valido.");
            return;
        }


        Usuario usuarioEncontrado = null;
        for (Usuario usuario : usuariosRegistrados) {
            if (usuario.getNumeroIdentificacion() == numeroIdentificador) {
                usuarioEncontrado = usuario;
                break;
            }
        }


        if (usuarioEncontrado != null) {

            System.out.println("Usuario encontrado:");
            System.out.println(usuarioEncontrado);


            System.out.println("Ingrese los nuevos datos del usuario:");

            System.out.print("Nombre: ");
            String nombre = scanner.nextLine();
            if (!nombre.isEmpty()) {
                usuarioEncontrado.setNombre(nombre);
            }

            System.out.print("Nuevo numero de identificacion: ");
            int nuevoNumeroIdentificacion = scanner.nextInt();
            scanner.nextLine();
            if (nuevoNumeroIdentificacion > 0) {
                usuarioEncontrado.setNumeroIdentificacion(nuevoNumeroIdentificacion);
            }

            System.out.println("El usuario ha sido actualizado.");
        } else {
            System.out.println("No se hay ningun usuario con ese numero identificador.");
        }
    }

    public void buscarUsuarioPorNumeroDeIdentificacion() {

        Scanner scanner = new Scanner(System.in);


        System.out.println("Ingrese el numero identificador a buscar:");
        int numeroIdentificador = scanner.nextInt();
        scanner.nextLine();


        if (numeroIdentificador <= 0) {
            System.out.println("Debe ingresar un numero identificador valido.");
            return;
        }


        Usuario usuarioEncontrado = null;
        for (Usuario usuario : usuariosRegistrados) {
            if (usuario.getNumeroIdentificacion() == numeroIdentificador) {
                usuarioEncontrado = usuario;
                break;
            }
        }


        if (usuarioEncontrado != null) {

            System.out.println("Usuario encontrado:");
            System.out.println(usuarioEncontrado);
        } else {
            System.out.println("No se encontro ningun usuario con ese numero de identificador.");
        }
    }

    public void listarLibrosPrestados() {
        Scanner scanner = new Scanner(System.in);


        if (usuariosRegistrados.isEmpty()) {
            System.out.println("No hay usuarios registrados.");
            return;
        }


        System.out.println("Ingrese el número identificador del usuario para ver la lista de libros prestados:");
        int numeroIdentificador = scanner.nextInt();
        scanner.nextLine();


        Usuario usuarioEncontrado = null;
        for (Usuario usuario : usuariosRegistrados) {
            if (usuario.getNumeroIdentificacion() == numeroIdentificador) {
                usuarioEncontrado = usuario;
                break;
            }
        }


        if (usuarioEncontrado != null) {

            System.out.println("Lista de libros prestados al usuario:");
            ArrayList<Libro> librosPrestados = usuarioEncontrado.getLibrosPrestados();
            if (librosPrestados.isEmpty()) {
                System.out.println("El usuario no tiene ningun libro prestado.");
            } else {
                for (Libro libro : librosPrestados) {
                    System.out.println(libro);
                }
            }
        } else {
            System.out.println("No se encontro ningun usuario con ese numero identificador.");
        }
    }

    public void eliminarUsuario() {
        Scanner scanner = new Scanner(System.in);


        System.out.println("Ingrese el numero identificador del usuario a eliminar:");
        int numeroIdentificador = scanner.nextInt();
        scanner.nextLine();


        if (numeroIdentificador <= 0) {
            System.out.println("Debe ingresar un número identificador valido.");
            return;
        }


        Usuario usuarioEncontrado = null;
        for (Usuario usuario : usuariosRegistrados) {
            if (usuario.getNumeroIdentificacion() == numeroIdentificador) {
                usuarioEncontrado = usuario;
                break;
            }
        }


        if (usuarioEncontrado != null) {

            usuariosRegistrados.remove(usuarioEncontrado);
            System.out.println("El usuario ha sido borrado correctamente.");
        } else {
            System.out.println("No se encontro ningun usuario con ese numero identificador.");
        }
    }

    public void prestarLibro() {
        Scanner scanner = new Scanner(System.in);


        System.out.println("Ingrese su numero identificador:");
        int numeroIdentificador = scanner.nextInt();
        scanner.nextLine();


        if (numeroIdentificador <= 0) {
            System.out.println("Debe ingresar un numero identificador valido.");
            return;
        }


        Usuario usuarioEncontrado = null;
        for (Usuario usuario : usuariosRegistrados) {
            if (usuario.getNumeroIdentificacion() == numeroIdentificador) {
                usuarioEncontrado = usuario;
                break;
            }
        }


        if (usuarioEncontrado != null) {

            System.out.println("Ingrese el titulo del libro que desea solqwerucitar:");
            String tituloLibro = scanner.nextLine();


            if (tituloLibro.isEmpty()) {
                System.out.println("Debe ingresar el titulo de un libro.");
                return;
            }


            Libro libroEncontrado = null;
            for (Libro libro : inventarioLibros) {
                if (libro.getTitulo().equalsIgnoreCase(tituloLibro)) {
                    libroEncontrado = libro;
                    break;
                }
            }


            if (libroEncontrado != null) {

                if (libroEncontrado.isDisponible()) {

                    System.out.println("El libro esta disponible. ¿Desea reservarlo? (S/N)");
                    String respuesta = scanner.nextLine().toUpperCase();
                    if (respuesta.equals("S")) {

                        libroEncontrado.setDisponible(false);

                        usuarioEncontrado.getLibrosPrestados().add(libroEncontrado);
                        System.out.println("¡Libro reservado!");
                    } else {
                        System.out.println("Reservacion denegada.");
                    }
                } else {
                    System.out.println("El libro no esta para reservar.");
                }
            } else {
                System.out.println("No se encontro ningun libro con ese titulo.");
            }
        } else {
            System.out.println("No se encontro ningun usuario con ese numero identificador");
        }
    }

    public void devolverLibro() {
        Scanner scanner = new Scanner(System.in);


        System.out.println("Ingrese el tqwertulo del libro que desea devolver:");
        String tituloLibro = scanner.nextLine();


        if (tituloLibro.isEmpty()) {
            System.out.println("Debe ingresar el título del libro.");
            return;
        }


        System.out.println("Ingrese su numero identificador:");
        int numeroIdentificador = scanner.nextInt();
        scanner.nextLine();


        if (numeroIdentificador <= 0) {
            System.out.println("Debe ingresar un numero identificador valido.");
            return;
        }


        Usuario usuarioEncontrado = null;
        for (Usuario usuario : usuariosRegistrados) {
            if (usuario.getNumeroIdentificacion() == numeroIdentificador) {
                usuarioEncontrado = usuario;
                break;
            }
        }


        if (usuarioEncontrado != null) {

            boolean libroEncontrado = false;
            ArrayList<Libro> librosPrestados = usuarioEncontrado.getLibrosPrestados();
            for (Libro libro : librosPrestados) {
                if (libro.getTitulo().equalsIgnoreCase(tituloLibro)) {

                    librosPrestados.remove(libro);

                    for (Libro libroInventario : inventarioLibros) {
                        if (libroInventario.getTitulo().equalsIgnoreCase(tituloLibro)) {
                            libroInventario.setDisponible(true);
                            break;
                        }
                    }
                    libroEncontrado = true;
                    System.out.println("Libro devuelto con exito.");
                    break;
                }
            }
            if (!libroEncontrado) {
                System.out.println("No se encontro ningun libro con el titulo proporcionado en su lista de libros prestados.");
            }
        } else {
            System.out.println("No se encontro ningun usuario con ese numero identificador");
        }
    }
}